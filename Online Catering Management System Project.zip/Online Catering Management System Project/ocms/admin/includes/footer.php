<div class="footer">
            <p>© 2020 Online Catering Management System.</p>
        </div>